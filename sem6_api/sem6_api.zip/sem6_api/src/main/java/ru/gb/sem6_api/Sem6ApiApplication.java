package ru.gb.sem6_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sem6ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sem6ApiApplication.class, args);
	}

}
